var c=require("./calc");

console.log(c.add(100,20));
console.log(c.sub(100,20));
console.log(c.mul(100,20));
console.log(c.mod(100,20));
console.log(c.div(100,20));
console.log("Message :"+c.message);

