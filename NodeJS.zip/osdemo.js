var os=require("os");

console.log("Platform :"+os.platform());
console.log("Total Memory :"+os.totalmem());
console.log("Free Memory :"+os.freemem());
console.log("Home dir :"+os.homedir());
console.log("Temp dir :"+os.tmpdir());
console.log("Os Type :"+os.type());

