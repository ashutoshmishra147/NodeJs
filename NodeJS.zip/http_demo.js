var http=require("http");
var url=require("url");


server=http.createServer(function(request,response){
console.log("Method :"+request.method);
console.log("Url  :"+request.url);
var myURL=new url.URL("http://localhost:8081"+request.url);
console.log("Url  :"+myURL);

myURL.searchParams.forEach(function(v,n){
console.log(n+"  "+v);
});



response.end("Hello World!!!!");
});

server.listen(8081,function(){
    console.log("Server listening on port 8081");
})



