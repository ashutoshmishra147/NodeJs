var fs=require("fs");


data=fs.readFileSync("welcome.js");

console.log("Contents :\n"+data);

console.log("File Reading over....");



