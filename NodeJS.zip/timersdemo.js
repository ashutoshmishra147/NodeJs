function welcome(){
    console.log("Welcome To Node JS @ Syntel")
}


var timer=setInterval(welcome,1000);


function clear(){
clearInterval(timer);
}

setTimeout(clear,5000);
