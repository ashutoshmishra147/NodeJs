var events=require("events");


var emitter=new events.EventEmitter();



emitter.on("connect",function(){
    console.log("Connection established...")
     emitter.emit("data")

});

emitter.addListener("data",function(){
    console.log("Data recieved from Client...");
})

emitter.emit("connect");

console.log("EventsDemo Program over....");


