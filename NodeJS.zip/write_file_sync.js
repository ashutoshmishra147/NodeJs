var fs=require("fs");

data="Hello Students!!! Practice makes man perfect";


fs.writeFileSync("a.txt",data);


console.log("File writing over....");



