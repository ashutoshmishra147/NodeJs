var fs=require("fs");

data="Hello Students!!! Practice makes man perfect";


fs.writeFile("a.txt",data,function(err){
if(err)
return console.log(err);
console.log("Writing the contents in a file...")
});

console.log("File writing over....");



