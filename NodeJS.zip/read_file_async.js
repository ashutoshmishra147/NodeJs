var fs=require("fs");


fs.readFile("welcome.js",function(err,data){
if(err)
return console.log(err);
console.log("Contents :\n"+data);

});

console.log("File Reading over....");



